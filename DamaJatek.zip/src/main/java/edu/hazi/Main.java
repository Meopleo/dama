package edu.hazi;

import edu.hazi.view.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("Dáma játék indítása...");
        new MainFrame();
    }
}
